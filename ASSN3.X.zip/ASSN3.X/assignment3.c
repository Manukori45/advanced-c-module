#include <xc.h>
#include "main.h"
#include "ass3head.h"

int i=0;
static long int wait=0;
void glow_on_press(unsigned char key)
{
	static int flag=0;
    if(key==SWITCH1){
        LED=0X00;
        flag=1;
    }
    else if(key==SWITCH2){
        LED=0X00;
        flag=2;
    }
    else if(key==SWITCH3){
        LED=0xAA;
        flag=3;
    }
    else if(key==SWITCH4){
        LED=0x0F;
        flag=4;
    }
    if(key!=0x0F){
        wait=0;
    }
    if(flag==1){
        if(wait++==5000){
            pattern1();
            wait=0;
        }
    }
    else if(flag==2){
        if(wait++==5000){
            pattern2();
            wait=0;
        }
    }
    else if(flag==3){
        if(wait++==5000){
            LED=~LED;
            wait=0;
        }
    }
    else if(flag==4){
        if(wait++==5000){
            LED=~LED;
            wait=0;
        }
    }
}

static void init_config(void)
{
	ADCON1 = 0x0F;

	TRISB =0x00;
    LED=0x00;   //PORTB=0x00
	init_digital_keypad();
}

void main(void)
{
	unsigned char key;

	init_config();

	while (1)
	{
		key = read_digital_keypad(STATE_CHANGE);
		glow_on_press(key);
	}
}

void pattern1(){
    if(i<8){
        LED=(LED<<1)|1;
    }
    else if(i<16){
        LED=LED<<1;
    }
    else if(i<24){
        LED=(LED>>1)|0x80;
    }
    else if(i<32){
        LED=LED>>1;
    }
    else
    {
        i=0;
    }
    i++;
}

void pattern2(){
    if(i<8){
        LED=(LED<<1)|1;
    }
    else if(i<16){
        LED=LED<<1;
    }
    else{
        i=0;
    }
    i++;
}
